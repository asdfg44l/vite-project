(function(){"use strict";self.onmessage=s=>{console.log("multiply get message: ",s.data),self.postMessage("This is a data from multiply.js")}})();
